
<?php $__env->startSection('contain'); ?>
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <div class="content">

            <!-- Breadcrumb -->
            <div class="d-md-flex d-block align-items-center justify-content-between page-breadcrumb mb-3">
                <div class="my-auto mb-2">
                    <h2 class="mb-1">Director Dashboard</h2>
                    <nav>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('Home')); ?>"><i class="ti ti-smart-home"></i></a>
                            </li>
                            
                            <li class="breadcrumb-item active" aria-current="page">Director Dashboard</li>
                        </ol>
                    </nav>
                </div>
                <div class="d-flex my-xl-auto right-content align-items-center flex-wrap ">
                    
                    
                    <div class="ms-2 head-icons">
                        <a href="javascript:void(0);" class="" data-bs-toggle="tooltip" data-bs-placement="top"
                            data-bs-original-title="Collapse" id="collapse-header">
                            <i class="ti ti-chevrons-up"></i>
                        </a>
                    </div>
                </div>
            </div>
            <!-- /Breadcrumb -->
            <!-- Welcome Wrap -->
            <div class="card border-0">
                <div class="card-body d-flex align-items-center justify-content-between flex-wrap pb-1">
                    <div class="d-flex align-items-center mb-3">
                        <span class="avatar avatar-xl flex-shrink-0">
                            <img src="<?php echo e(asset('assets/img/profiles/no-img.jpg')); ?>" class="rounded-circle" alt="img">
                        </span>
                        <div class="ms-3">
                            <h3 class="mb-2">Welcome Back, <?php echo e(session('User_Name')); ?> <a href="javascript:void(0);"
                                    class="edit-icon"><i class="ti ti-edit fs-14"></i></a></h3>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
            <!-- /Welcome Wrap -->

            
            <div class="row justify-content-center align-items-center">
                

                
                <div class="row">
                    <div class="col-xl-4 d-flex">
                        <div class="card flex-fill border-primary attendance-bg">
                            <div class="card-body">
                                <div class="mb-4 text-center">
                                    <h4 class="fw-medium text-gray-5 mb-1" style="font-weight: 900 !important;">Attendance
                                    </h4>
                                    <h6 style="margin-top:15px;" id="punch_date"></h6>
                                    <h6 id="punch_time"></h6>

                                </div>

                                <div class="attendance-circle-progress attendance-progress mx-auto mb-3" data-value='65'
                                    style="display: none;" id="DivAttend">
                                    <span class="progress-left">
                                        <span class="progress-bar border-success"></span>
                                    </span>
                                    <span class="progress-right">
                                        <span class="progress-bar border-success"></span>
                                    </span>
                                    <div class="total-work-hours text-center w-100">
                                        <span class="fs-13 d-block mb-1">Total Hours</span>
                                        <h6 id="CalTime"></h6>
                                    </div>
                                </div>
                                <div class="text-center" style="display: none;" id="DivPunchOut">
                                    <!-- <div class="badge badge-dark badge-md mb-3">Production :  3.45 hrs</div>-->
                                    <br>
                                    <h6 class="fw-medium d-flex align-items-center justify-content-center mb-4">
                                        <i class="ti ti-fingerprint text-primary me-1"></i>
                                        <span id="PrintPunchIn"></span>
                                    </h6>
                                    <textarea class="form-control" name="Remarks" id="Remarks" placeholder="Remarks" cols="30" rows="5"></textarea>
                                    <a onclick="punch_out();" class="btn btn-primary w-100" style="margin-top: 10px;">Punch
                                        Out</a>
                                </div>

                                <div class="text-center" style="display: none;" id="DivPnchIn">
                                    <!-- <div class="badge badge-dark badge-md mb-3">Production :  3.45 hrs</div>-->
                                    <br>
                                    <h6 class="fw-medium d-flex align-items-center justify-content-center mb-4">
                                        <i class="ti ti-fingerprint text-primary me-1"></i>
                                    </h6>
                                    <textarea class="form-control" name="Remarks" id="Remarks" placeholder="Remarks" cols="30" rows="5"></textarea>
                                    <a onclick="punch_in();" class="btn btn-primary w-100" style="margin-top: 10px;">Punch
                                        In</a>
                                </div>


                            </div>
                        </div>
                    </div>
                    <div class="col-xl-8 d-flex">
                        <div class="card flex-fill border-primary attendance-bg">
                            <div class="card-body">

                                <!-- Header -->
                                <div class="mb-3 text-center">
                                    <h4 class="fw-medium text-gray-5 mb-1" style="font-weight:900;">Current Month Attendance
                                        Summary</h4>
                                    <h6 class="mt-2" id="punch_date"></h6>
                                    <h6 id="punch_time"></h6>
                                </div>


                                <!-- Table -->
                                <div class="table-responsive border rounded" style="max-height:380px; overflow:auto;">
                                    <table class="table table-bordered table-hover mb-0 text-center align-middle">

                                        <thead class="table-primary sticky-top">
                                            <tr>
                                                <th style="min-width:120px;">Sl</th>
                                                <th style="min-width:120px;">Date</th>
                                                <th style="min-width:120px;">In Time</th>
                                                <th style="min-width:140px;">Out Time</th>
                                                <th style="min-width:140px;">Remarks</th>
                                                <th style="min-width:120px;">Status</th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                            <?php if($report->isNotEmpty()): ?>
                                                <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($data->Sl); ?></td>
                                                        <td><?php echo e($data->MDate); ?></td>
                                                        <td><?php echo e($data->InTime); ?></td>
                                                        <td><?php echo e($data->OutTime); ?></td>
                                                        <td><?php echo e($data->Remrks); ?></td>
                                                        <?php if($data->Status == 'Absent'): ?>
                                                            <td>
                                                                <span class="badge bg-danger"><?php echo e($data->Status); ?></span>
                                                            </td>
                                                        <?php elseif($data->Status == 'Holiday'): ?>
                                                            <td>
                                                                <span class="badge bg-warning"><?php echo e($data->Status); ?></span>
                                                            </td>
                                                        <?php else: ?>
                                                            <td>
                                                                <span class="badge bg-success"><?php echo e($data->Status); ?></span>
                                                            </td>
                                                        <?php endif; ?>

                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <p class="text-center text-muted">No report found</p>
                                            <?php endif; ?>



                                        </tbody>

                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>

            

            
        </div>



    </div>
    <!-- /Page Wrapper -->

    <!-- Add Leaves -->
    <div class="modal fade" id="add_leaves">
        <div class="modal-dialog modal-dialog-centered modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add Leave</h4>
                    <button type="button" class="btn-close custom-btn-close" data-bs-dismiss="modal"
                        aria-label="Close">
                        <i class="ti ti-x"></i>
                    </button>
                </div>
                <form action="employee-dashboard.html">
                    <div class="modal-body pb-0">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label class="form-label">Employee Name</label>
                                    <select class="select2">
                                        <option>Select</option>
                                        <option>Rajkumar Maity</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label class="form-label">Leave Type</label>
                                    <select class="select2">
                                        <option>Select</option>
                                        <option>Medical Leave</option>
                                        <option>Casual Leave</option>
                                        <option>Earn Leave</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">From </label>
                                    <div class="input-icon-end position-relative">
                                        <input type="text" class="form-control datetimepicker"
                                            placeholder="dd/mm/yyyy">
                                        <span class="input-icon-addon">
                                            <i class="ti ti-calendar text-gray-7"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">To </label>
                                    <div class="input-icon-end position-relative">
                                        <input type="text" class="form-control datetimepicker"
                                            placeholder="dd/mm/yyyy">
                                        <span class="input-icon-addon">
                                            <i class="ti ti-calendar text-gray-7"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">No of Days</label>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Remaining Days</label>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label class="form-label">Reason</label>
                                    <textarea class="form-control" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light me-2" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Leaves</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /Add Leaves -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        $('.select2').select2({
            width: '100%', // respect your min-width:100% css
            dropdownParent: $('#add_leaves') // important inside modal
        });
        var pIsAttend = "<?php echo e(session('IsAttend') ?? 0); ?>"
        var pAttendDate = "<?php echo e(session('AttendDate') ?? 0); ?>"
        var pAttendTime = "<?php echo e(session('AttendTime') ?? 0); ?>"
        var parts = pAttendDate.split('-');
        var isoDate = parts[2] + "-" + parts[1] + "-" + parts[0];
        pAttendDate = isoDate;
    </script>
    <script src="<?php echo e(asset('assets/js/dayjs.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/common/attand.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\WorkSpare\resources\views/dashboard/directordash.blade.php ENDPATH**/ ?>