
<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap5.min.css')); ?>">
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('contain'); ?>
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <div class="content">
            <?php if($error): ?>
                <div class="alert alert-danger">
                    <strong>Error:</strong> <?php echo e($error); ?>

                </div>
            <?php endif; ?>
            <!-- Breadcrumb -->
            <div class="d-md-flex d-block align-items-center justify-content-between page-breadcrumb mb-3">
                <div class="my-auto mb-2">
                    <h2 class="mb-1">Employee</h2>
                    <nav>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('Home')); ?>"><i class="ti ti-smart-home"></i></a>
                            </li>
                            <li class="breadcrumb-item">
                                Employee
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Employee List</li>
                        </ol>
                    </nav>
                </div>
                <div class="d-flex my-xl-auto right-content align-items-center flex-wrap ">
                    <div class="me-2 mb-2">
                        
                    </div>
                    <div class="me-2 mb-2">
                        
                    </div>
                    
                    <div class="head-icons ms-2">
                        <a href="javascript:void(0);" class="" data-bs-toggle="tooltip" data-bs-placement="top"
                            data-bs-original-title="Collapse" id="collapse-header">
                            <i class="ti ti-chevrons-up"></i>
                        </a>
                    </div>
                </div>
            </div>
            <!-- /Breadcrumb -->

            <div class="row">

                <!-- Total Plans -->
                <div class="col-lg-3 col-md-6 d-flex">
                    <div class="card flex-fill">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center overflow-hidden">
                                <div>
                                    <span class="avatar avatar-lg bg-dark rounded-circle"><i class="ti ti-users"></i></span>
                                </div>
                                <div class="ms-2 overflow-hidden">
                                    <p class="fs-12 fw-medium mb-1 text-truncate">Total Employee</p>
                                    <h4>24</h4>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- /Total Plans -->

                <!-- Total Plans -->
                <div class="col-lg-3 col-md-6 d-flex">
                    <div class="card flex-fill">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center overflow-hidden">
                                <div>
                                    <span class="avatar avatar-lg bg-success rounded-circle"><i
                                            class="ti ti-user-share"></i></span>
                                </div>
                                <div class="ms-2 overflow-hidden">
                                    <p class="fs-12 fw-medium mb-1 text-truncate">Active</p>
                                    <h4>24</h4>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- /Total Plans -->

                <!-- Inactive Plans -->
                <div class="col-lg-3 col-md-6 d-flex">
                    <div class="card flex-fill">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center overflow-hidden">
                                <div>
                                    <span class="avatar avatar-lg bg-danger rounded-circle"><i
                                            class="ti ti-user-pause"></i></span>
                                </div>
                                <div class="ms-2 overflow-hidden">
                                    <p class="fs-12 fw-medium mb-1 text-truncate">InActive</p>
                                    <h4>0</h4>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- /Inactive Companies -->

                <!-- No of Plans  -->
                <div class="col-lg-3 col-md-6 d-flex">
                    <div class="card flex-fill">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center overflow-hidden">
                                <div>
                                    <span class="avatar avatar-lg bg-info rounded-circle"><i
                                            class="ti ti-user-plus"></i></span>
                                </div>
                                <div class="ms-2 overflow-hidden">
                                    <p class="fs-12 fw-medium mb-1 text-truncate">New Joiners</p>
                                    <h4>0</h4>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- /No of Plans -->

            </div>

            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
                    <h5>Staff Details</h5>
                    <div class="d-flex my-xl-auto right-content align-items-center flex-wrap row-gap-3">
                        
                        
                        <div class="dropdown me-3">
                            <button type="button" class="btn btn-primary d-inline-flex align-items-center"
                                onclick="open_page(0)">Add New</button>
                        </div>
                        
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="custom-datatable-filter table-responsive">
                        <table class="table datatable">
                            <thead class="thead-light">
                                <tr>
                                    <th class="no-sort">
                                        SL
                                    </th>
                                    <th>Emp Code</th>
                                    <th>Staff Name</th>
                                    <th>Email</th>
                                    <th>Contact No.</th>
                                    <th>Gender</th>
                                    <th>Educational Qualification</th>
                                    <th>Residence</th>
                                    <th>Present Working</th>
                                    <th>Domain</th>
                                    <th>Department</th>
                                    <th>Date Of Joining</th>
                                    <th>Emp. Type</th>
                                    <th>EPF No.</th>
                                    <th>ESIC No.</th>
                                    <th>UAN No.</th>
                                    <th>Bank Name</th>
                                    <th>Acct. No.</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php $__currentLoopData = $emp_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($i++); ?>

                                        </td>
                                        <td><?php echo e($emp->ECode); ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo e(asset('assets/img/profiles/no-img.jpg')); ?>"
                                                    class="img-fluid rounded-circle avatar avatar-md" alt="img">
                                                <div class="ms-2">
                                                    <p class="text-dark mb-0">
                                                        <?php echo e($emp->FstNm . ' ' . $emp->MdlNm . ' ' . $emp->LstNm); ?>

                                                    </p>
                                                    <span class="fs-12"><?php echo e($emp->DesigNm); ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo e($emp->Email); ?> </td>
                                        <td><?php echo e($emp->MobNo); ?></td>
                                        <td><?php echo e($emp->Gndr); ?></td>
                                        <td><?php echo e($emp->EQual); ?></td>
                                        <td><?php echo e($emp->ERes); ?></td>
                                        <td><?php echo e($emp->EBrNms); ?></td>
                                        <td><?php echo e($emp->DomainNm); ?></td>
                                        <td><?php echo e($emp->DeptNm); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($emp->EJDt)->format('d-M-Y')); ?></td>
                                        <td> <?php echo e($emp->EType); ?> </td>
                                        <td> <?php echo e($emp->Epf); ?> </td>
                                        <td> <?php echo e($emp->Esic); ?> </td>
                                        <td> <?php echo e($emp->Uan); ?> </td>
                                        <td> <?php echo e($emp->EBank); ?> </td>
                                        <td> <?php echo e($emp->EAcNo); ?> </td>
                                        <td>
                                            <div class="action-icon d-inline-flex">
                                                <a href="javascript:void(0);" class="me-2" title="Edit Employee"
                                                    onclick="open_page(<?php echo e($emp->EId); ?>);"><i
                                                        class="ti ti-edit"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>



    </div>
    <!-- /Page Wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script>
        function setCookie(name, value, minutes) {
            const expires = new Date(Date.now() + minutes * 60 * 1000).toUTCString();
            document.cookie =
                name + "=" + encodeURIComponent(value) +
                "; expires=" + expires +
                "; path=/" +
                "; SameSite=Strict" +
                "; Secure"; // works only on HTTPS
        }

        function open_page(p) {
            if (p == 0) {
                window.location.replace(baseUrl + '/Payroll/EmployeeProfile/Appointment');
            } else {
                setCookie('edt_emp_id',p,1);
                window.location.replace(baseUrl + '/Payroll/EmployeeProfile/Appointment');
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\WorkSpare\resources\views/payroll/employeelist.blade.php ENDPATH**/ ?>