<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <!-- Logo -->
    <div class="sidebar-logo">
        <a href="<?php echo e(route('Home')); ?>" class="logo logo-normal">
            <img src="<?php echo e(asset('assets/img/logo.svg')); ?>" alt="Logo">
        </a>
        <a href="<?php echo e(route('Home')); ?>" class="logo-small">
            <img src="<?php echo e(asset('assets/img/logo-small.svg')); ?>" alt="Logo">
        </a>
        <a href="<?php echo e(route('Home')); ?>" class="dark-logo">
            <img src="<?php echo e(asset('assets/img/logo-white.svg')); ?>" alt="Logo">
        </a>
    </div>
    <!-- /Logo -->

    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul class="nav-menu">
                <li class="menu-title"><span>DASHBOARD</span></li>
                <li>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('Home')); ?>" class="active">
                                <i class="ti ti-smart-home"></i>
                                <span>Dashboard</span>
                            </a>

                        </li>
                    </ul>
                </li>
                <?php $__currentLoopData = $menue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menues): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="menu-title"><span><?php echo e($menues['module_name']); ?></span></li>
                    <?php $__currentLoopData = $menues['parents']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <ul>
                                <li class="submenu">
                                    <a href="javascript:void(0);">
                                        <i class="ti ti-box"></i><span><?php echo e($parent['parent_name']); ?></span>
                                        <span class="menu-arrow"></span>
                                    </a>
                                    <ul>
                                        <?php $__currentLoopData = $parent['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(count($child['sub_children']) > 0): ?>
                                                <li class="submenu submenu-two">
                                                    <a href="#"><?php echo e($child['child_name']); ?><span
                                                            class="menu-arrow inside-submenu"></span></a>
                                                    <ul>
                                                        <?php $__currentLoopData = $child['sub_children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><a href="<?php echo e(isset($sub['route']) && Route::has($sub['route']) ? route($sub['route']) : '#'); ?>"> <?php echo e($sub['sub_name']); ?> </a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                    </ul>
                                                </li>
                                            <?php else: ?>
                                                <?php if(!empty($child['child_name'])): ?>
                                                    <li>

                                                        <a href="<?php echo e(isset($child['route']) && Route::has($child['route']) ? route($child['route']) : '#'); ?>"><?php echo e($child['child_name']); ?></a>
                                                    </li>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </li>
                            </ul>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <li class="menu-title"><span>SETTINGS</span></li>
                <li>
                    <ul>
                        <li class="submenu">
                            <a href="javascript:void(0);">
                                <i class="ti ti-settings"></i><span>Settings</span>
                                <span class="menu-arrow"></span>
                            </a>
                            <ul>
                                <li><a href="#">General Settings</a></li>
                                <li><a href="#">Payroll Settings</a></li>
                                <li><a href="#">Salary Settings</a></li>
                                <li><a href="#">Financial Settings</a></li>
                                <li><a href="#">Roles Settings</a></li>
                                <li><a href="#">Activity Types</a></li>
                                <li><a href="#">Asset Categories</a></li>
                            </ul>
                        </li>

                        <!-- Bottom -->
                        <li><a href="#"><i class="ti ti-lock-square"></i><span>Lock Screen</span></a></li>
                        <li><a href="<?php echo e(route('cng-pass')); ?>"><i class="ti ti-help-triangle"></i><span>Change Password</span></a></li>
                        <li><a href="<?php echo e(route('logout')); ?>"><i class="ti ti-logout"></i><span>Signout</span></a></li>

                    </ul>

                </li>




            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar -->
<?php /**PATH D:\Project\Laravel\WorkSpare\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>