
<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.css')); ?>">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('contain'); ?>
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <div class="content">
            <?php if($error): ?>
                <div class="alert alert-danger">
                    <strong>Error:</strong> <?php echo e($error); ?>

                </div>
            <?php endif; ?>
            <!-- Breadcrumb -->
            <div class="d-md-flex d-block align-items-center justify-content-between page-breadcrumb mb-3">
                <div class="my-auto mb-2">
                    <h2 class="mb-1">Attandance Report</h2>
                    <nav>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('Home')); ?>"><i class="ti ti-smart-home"></i></a>
                            </li>
                            <li class="breadcrumb-item">
                                Reports
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Attandance List</li>
                        </ol>
                    </nav>
                </div>
                <div class="d-flex my-xl-auto right-content align-items-center flex-wrap ">
                    <div class="me-2 mb-2">
                        
                    </div>
                    <div class="me-2 mb-2">
                        
                    </div>
                    
                    <div class="head-icons ms-2">
                        <a href="javascript:void(0);" class="" data-bs-toggle="tooltip" data-bs-placement="top"
                            data-bs-original-title="Collapse" id="collapse-header">
                            <i class="ti ti-chevrons-up"></i>
                        </a>
                    </div>
                </div>
            </div>
            <!-- /Breadcrumb -->



            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
                    <h5>Attandance Details</h5>
                    <div class="d-flex my-xl-auto right-content align-items-center flex-wrap row-gap-3">
                        <div class="me-3 flex-fill">
                            <label for="frm_date" class="form-label">From Date</label>
                            <input type="text" id="frm_date" placeholder="DD/MM/YYYY"
                                class="form-control bs-datepicker-format" />
                        </div>
                        <div class="me-3 flex-fill">
                            <label for="to_date" class="form-label">To Date</label>
                            <input type="text" id="to_date" placeholder="DD/MM/YYYY"
                                class="form-control bs-datepicker-format" />
                        </div>
                        <div class="dropdown me-3 ">
                            <label for="emp_id" class="form-label">Select Employee</label>
                            <select name="emp_id" id="emp_id" class="select2 form-control">
                                <option value="" Selected Disabled>Select Employee</option>
                                <option value="0">All Employee</option>
                                <?php $__currentLoopData = $emp_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->Id); ?>"><?php echo e($list->StaffNm); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="dropdown me-3 ">
                            <a class="btn btn-primary" style="margin-top: 27px;" onclick="gen_details();">Genereate</a>
                            <a class="btn btn-success" style="margin-top: 27px;" onclick="export_excel();">
                                <i class="fa-solid fa-file-excel"></i> Export To Excel
                            </a>
                        </div>

                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="custom-datatable-filter table-responsive">
                        <table class="table" id="rpt_attend">
                            <thead class="thead-light">
                                <tr>
                                    <th class="no-sort">
                                        SL
                                    </th>
                                    <th>Staff Name</th>
                                    <th>Punch Date</th>
                                    <th>In Time</th>
                                    <th>Punch Remarks</th>
                                    <th>Out Time</th>
                                    <th>Out Remarks</th>
                                </tr>
                            </thead>
                            <tbody>




                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>



    </div>
    <!-- /Page Wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dayjs.min.js')); ?>"></script>

    <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
    <script>
        $(".select2").select2();
        $(document).ready(function() {
            let picker = $('.bs-datepicker-format').datepicker({
                format: 'dd/mm/yyyy',
                todayHighlight: true,
                todayBtn: 'linked',
                autoclose: true
            });

            // Set today's date
            picker.datepicker('setDate', new Date());


        });

        var table = $('#rpt_attend').DataTable({
            bFilter: true,
            ordering: true,
            info: true,
            language: {
                search: ' ',
                sLengthMenu: 'Row Per Page _MENU_ Entries',
                searchPlaceholder: "Search",
                info: "Showing _START_ - _END_ of _TOTAL_ entries",
                paginate: {
                    next: '<i class="ti ti-chevron-right"></i>',
                    previous: '<i class="ti ti-chevron-left"></i>'
                },
            },
            dom: 'Bfrtip',
            buttons: [{
                extend: 'excelHtml5',
                title: null,
                className: 'd-none',
                filename: 'Attendance_Report', // actual file name
                exportOptions: {
                    modifier: {
                        page: 'all' // export all rows
                    }
                }
            }]
        });

        function format_date(p) {
            if (p == '') {
                return '';
            } else {
                let parts = p.split('/'); // ["12","10","2025"]
                let dateObj = new Date(parts[2], parts[1] - 1, parts[0]);
                dateObj = dayjs(dateObj).format("YYYY-MM-DD");
                return dateObj;
            }

        }
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });

        function gen_details() {
            var pFrm_Date = format_date($("#frm_date").val());
            var pTo_Date = format_date($("#to_date").val());
            var pEmp_Id = $("#emp_id").val();
            if (pEmp_Id == null) {
                pEmp_Id = 0;
            }


            if (pFrm_Date == '') {
                warning_alert("Please Select From Date !!");
            } else if (pTo_Date == '') {
                warning_alert("Please Select To Date !!");
            } else {

                $.ajax({
                    url: baseUrl + "/Report/ProcessAttendDetails",
                    type: "GET",
                    data: {
                        pFrm_Date: pFrm_Date,
                        pTo_Date: pTo_Date,
                        pEmp_Id: pEmp_Id
                    },
                    success: function(response) {
                        // console.log(response);
                        if (response.status === "success") {
                            $("#nb-global-spinner").fadeIn();
                            var data = response.data;
                            var rows = [];
                            var sl = 1;


                            // Then in your AJAX success
                            table.clear(); // remove old rows
                            data.forEach(function(tbldata) {
                                rows.push([
                                    sl++,
                                    tbldata.EmpName ?? '',
                                    dayjs(tbldata.AttnDate, "MM-DD-YYYY", true)
                                    .format("DD-MMM-YYYY") ?? '',
                                    tbldata.AttnTime ?? '',
                                    tbldata.AttnRemrks ?? '',
                                    tbldata.OutTime ?? '',
                                    tbldata.OutRemrks ?? ''
                                ]);
                            });
                            table.rows.add(rows).draw();
                            $("#nb-global-spinner").fadeOut();
                        } else {
                            error_message("Something Went Wrong !!");
                        }
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            let errors = JSON.parse(xhr.responseText).errors;
                            let errorMessages = Object.values(errors).flat().join("\n");
                            error_message(errorMessages);
                        } else {
                            console.error("Error:", xhr);
                            error_message(xhr.responseJSON.message);
                        }
                    },
                });
            }


        }

        function export_excel() {

            table.button('.buttons-excel').trigger(); // trigger hidden Excel export
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\WorkSpare\resources\views/payroll/rptattnd.blade.php ENDPATH**/ ?>