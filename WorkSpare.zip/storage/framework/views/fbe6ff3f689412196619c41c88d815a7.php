<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('contain'); ?>
    <div class="">
        <div class="text-center mb-3">
            <h2 class="mb-2">Sign In</h2>
            <p class="mb-0">Please enter your details to sign in</p>
        </div>
        <form>
            <div class="mb-3">
                <label class="form-label">Staff Code</label>
                <div class="input-group">
                    <input type="text" class="form-control border-end-0" autocomplete="off" id="user_name" name="user_name">
                    <span class="input-group-text border-start-0">
                        <i class="ti ti-mail"></i>
                    </span>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <div class="pass-group">
                    <input type="password" class="pass-input form-control" id="user_pass" autocomplete="off" name="user_pass">
                    <span class="ti toggle-password ti-eye-off"></span>
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="d-flex align-items-center">
                    <div class="form-check form-check-md mb-0">
                        <input class="form-check-input" id="remember_me" type="checkbox">
                        <label for="remember_me" class="form-check-label mt-0">Remember Me</label>
                    </div>
                </div>
                <div class="text-end">
                    <a href="#" class="link-danger">Forgot Password?</a>
                </div>
            </div>
            <div class="mb-3">
                <button type="button" onclick="proc_login();" class="btn btn-primary w-100">Sign In</button>
            </div>
        </form>
        
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        baseUrl = "<?php echo e(url('/')); ?>";
        secretKey = "<?php echo e(config('app.key')); ?>";
    </script>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/crypto.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/auth/auth.js')); ?>"></script>
    <script>
        $(".select2").select2();
        
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('Auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\WorkSpare\resources\views/Auth/login.blade.php ENDPATH**/ ?>