<div class="footer d-sm-flex align-items-center justify-content-between border-top bg-white p-3">
				<p class="mb-0">2014 - 2025 &copy; SmartHR.</p>
				<p>Designed &amp; Developed By <a href="javascript:void(0);" class="text-primary">Rajib Dam</a></p>
			</div>
	</div>
	<!-- /Main Wrapper -->

<!-- jQuery -->
    <script src="<?php echo e(asset('assets/js/jquery-3.7.1.min.js')); ?>"></script>

	<!-- Bootstrap Core JS -->
	<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

	<!-- Feather Icon JS -->
	<script src="<?php echo e(asset('assets/js/feather.min.js')); ?>"></script>

	<!-- Slimscroll JS -->
	<script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

	<!-- Chart JS -->
	<script src="<?php echo e(asset('assets/plugins/apexchart/apexcharts.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/plugins/apexchart/chart-data.js')); ?>"></script>

	<!-- Chart JS -->
	<script src="<?php echo e(asset('assets/plugins/chartjs/chart.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/plugins/chartjs/chart-data.js')); ?>"></script>

	<!-- Datetimepicker JS -->
	<script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

	<!-- Daterangepikcer JS -->
	<script src="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.js')); ?>"></script>

	<!-- Summernote JS -->
	<script src="<?php echo e(asset('assets/plugins/summernote/summernote-lite.min.js')); ?>"></script>

	<!-- Bootstrap Tagsinput JS -->
	<script src="<?php echo e(asset('assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js')); ?>"></script>

	<!-- Select2 JS -->
	<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

	<!-- Color Picker JS -->
	<script src="<?php echo e(asset('assets/plugins/%40simonwep/pickr/pickr.es5.min.js')); ?>"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(asset('assets/js/alert.js')); ?>"></script>
	<?php echo $__env->yieldPushContent('script'); ?>
	<!-- Custom JS -->
	<script src="<?php echo e(asset('assets/js/theme-colorpicker.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

    <script>
		baseUrl = "<?php echo e(url('/')); ?>";
	</script>

</body>


<!-- Mirrored from smarthr.co.in/demo/html/template/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Aug 2025 17:21:27 GMT -->
</html><?php /**PATH D:\Project\Laravel\WorkSpare\resources\views/layouts/footer.blade.php ENDPATH**/ ?>